package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.exception.IBSExceptions;

public interface BankAdminDAO {
	public Set<BigInteger> getRequests();

	public Set<CreditCard> getCreditCardDetails(BigInteger uci);

	public Set<Beneficiary> getBeneficiaryDetails(BigInteger uci);

	public boolean checkedCreditCardDetails(BigInteger cardNumber) throws IBSExceptions;

	public boolean checkedBeneficiaryDetails(BigInteger accountNumber) throws IBSExceptions;
	
	public boolean decliningCreditCardDetails(BigInteger cardNumber) throws IBSExceptions;
	
	public boolean decliningBeneficiaryDetails(BigInteger accountNumber) throws IBSExceptions;
}
