package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.Set;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.dao.BankAdminDAO;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.util.JpaUtil;

@Service("BankAdminService")
public class Bank_AdminServiceImpl implements Bank_AdminService {
	@Autowired
	private BankAdminDAO bankRepresentativeDAO;
	private static Logger logger = Logger.getLogger(Bank_AdminServiceImpl.class);

	@Override
	public Set<BigInteger> showRequests() {
		logger.info("entering into showRequests method of Bank_AdminServiceImpl class");
		return bankRepresentativeDAO.getRequests();

	}

	@Override
	public Set<CreditCard> showUnapprovedCreditCards(BigInteger uci) {
		logger.info("entering into showUnapprovedCreditCards method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.getCreditCardDetails(uci);

	}

	@Override
	public Set<Beneficiary> showUnapprovedBeneficiaries(BigInteger uci) {
		logger.info("entering into showUnapprovedBeneficiaries method of BankRepresentativeServiceImpl class");
		return bankRepresentativeDAO.getBeneficiaryDetails(uci);
	}

	@Override
	public boolean saveCreditCardDetails(BigInteger cardNumber) throws IBSExceptions {
		logger.info("Entering into checkedCreditCardDetails method of Bank Admin in case of approved cards");
		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.checkedCreditCardDetails(cardNumber)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

	@Override
	public boolean saveBeneficiaryDetails(BigInteger accountNumber) throws IBSExceptions {
		logger.info("Entering into checkedBeneficiaryDetails method of Bank Admin in case of approved beneficiaries");

		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.checkedBeneficiaryDetails(accountNumber)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

	@Override
	public boolean disapproveCreditCard(BigInteger cardNumber) throws IBSExceptions {
		logger.info("Entering into checkedCreditCardDetails method of Bank Admin in case of disapproved cards");
		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.decliningCreditCardDetails(cardNumber)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

	@Override
	public boolean disapproveBenficiary(BigInteger accountNumber) throws IBSExceptions {
		logger.info(
				"Entering into checkedBeneficiaryDetails method of Bank Admin in case of disapproved beneficiaries");
		boolean result = false;
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		if (!entityTransaction.isActive()) {
			entityTransaction.begin();
		}
		if (bankRepresentativeDAO.decliningBeneficiaryDetails(accountNumber)) {
			result = true;
		}
		entityTransaction.commit();
		return result;
	}

}
