package com.cg.ibs.rm.ui;

public enum Status {
		ACTIVE, BLOCKED, PENDING
}
