package com.cg.ibs.rm.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.dao.AutoPaymentDAO;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.util.JpaUtil;

@Service("AutoPaymentService")
public class AutoPaymentServiceImpl implements AutoPaymentService {
	@Autowired
	private AutoPaymentDAO autoPaymentDao;
	private static final Logger LOGGER = Logger.getLogger(AutoPaymentServiceImpl.class.getName());

	@Override
	public Set<AutoPayment> showAutopaymentDetails(BigInteger uci) throws IBSExceptions {
		LOGGER.info("entered showAutopaymentDetails in autopaymentservimpl");
		return autoPaymentDao.getAutopaymentDetails(uci);

	}

	@Override
	public Set<ServiceProvider> showIBSServiceProviders() {
		LOGGER.info("entered  showIBSServiceProviders in autopaymentservimpl");
		return autoPaymentDao.showServiceProviderList();

	}

	@Override
	public boolean autoDeduction(BigInteger uci, BigInteger accountNumber, AutoPayment autoPayment)
			throws IBSExceptions {
		LOGGER.info("entered  autodeduction in autopaymentservimpl");
		EntityTransaction transaction = JpaUtil.getTransaction();
		LocalDate today = LocalDate.now();
		boolean validAutoDeduct = false;
		LOGGER.debug(autoPaymentDao.getCurrentBalance(accountNumber));
		if (Pattern.matches("^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/((?:[0-9]{2})?[0-9]{2})$", autoPayment.getDateOfStart())) {
			DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate startOfAutoPayment = LocalDate.parse(autoPayment.getDateOfStart(), dtFormatter);
			if (!transaction.isActive()) {
				transaction.begin();
			}
			if (!startOfAutoPayment.isBefore(today)) {
				autoPaymentDao.copyDetails(uci, autoPayment);
				if (today.equals(startOfAutoPayment)
						&& (0 <= autoPaymentDao.getCurrentBalance(accountNumber).compareTo(autoPayment.getAmount()))) {
					BigDecimal balance = autoPaymentDao.getCurrentBalance(accountNumber)
							.subtract(autoPayment.getAmount());
					autoPaymentDao.setCurrentBalance(balance, accountNumber);
					startOfAutoPayment.plusMonths(1);
					LOGGER.debug(autoPaymentDao.getCurrentBalance(accountNumber));
					
				}
				validAutoDeduct = true;
			}
			transaction.commit();
		}
		
		return validAutoDeduct;
	}

	@Override
	public boolean updateRequirements(BigInteger uci, BigInteger spi) throws IBSExceptions {
		boolean result = false;
		LOGGER.info("entered updateRequirements in autopaymentservimpl");
		EntityTransaction transaction = JpaUtil.getTransaction();
		if (!transaction.isActive()) {
			transaction.begin();
		}
		result = autoPaymentDao.deleteDetails(uci, spi);
		transaction.commit();
		return result;
	}

}