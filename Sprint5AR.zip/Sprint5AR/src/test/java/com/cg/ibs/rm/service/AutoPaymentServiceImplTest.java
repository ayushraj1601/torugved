
package com.cg.ibs.rm.service;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProviderId;
import com.cg.ibs.rm.exception.IBSExceptions;


@Service("AutoPaymentserviceImpl")
class AutoPaymentServiceImplTest {
	private ApplicationContext context = new ClassPathXmlApplicationContext("applicantContext.xml");
	AutoPaymentService autoPaymentServiceImpl = context.getBean(AutoPaymentServiceImpl.class);

	@Test
	public void autoDeductionTest2() {
		AutoPayment autoPayment = new AutoPayment(
				new ServiceProviderId(new BigInteger("1001"), new BigInteger("5555111151513301")), new BigDecimal("100"),
				"12/12/2019");
		try {
			assertTrue(autoPaymentServiceImpl.autoDeduction(new BigInteger("5555111151513301"), new BigInteger("11111111111"),
					autoPayment));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service has already been opted.", throwable.getMessage());
		}

	}

	@Test
	public void autoDeductionTest3() {
		AutoPayment autoPayment = new AutoPayment(
				new ServiceProviderId(new BigInteger("1001"), new BigInteger("5555111151513301")), new BigDecimal("100"),
				"12/12/2019");
		try {
			assertTrue((autoPaymentServiceImpl.autoDeduction(new BigInteger("5555111151513301"), new BigInteger("11111111111"),
					autoPayment)));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service has already been opted.", throwable.getMessage());
		}

	}

	@Test
	public void updateRequirementsTest1() {
		try {
			assertTrue(autoPaymentServiceImpl.updateRequirements(new BigInteger("5555111151513301"),
					new BigInteger("1000001")));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service doesn't exist", throwable.getMessage());
		}
	}

	@Test
	public void updateRequirementsTest2() {
		try {
			assertFalse((autoPaymentServiceImpl.updateRequirements(new BigInteger("5555111151513301"),
					new BigInteger("3"))));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service doesn't exist", throwable.getMessage());
		}
	}

	@Test
	public void updateRequirementsTest3() {
		try {
			assertEquals(true, (autoPaymentServiceImpl.updateRequirements(new BigInteger("5555111151513301"),
					new BigInteger("3"))));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto payment service doesn't exist", throwable.getMessage());
		}
	}

	@Test
	public void showAutopaymentDetailsTest() {
		try {
			assertNotNull(autoPaymentServiceImpl.showAutopaymentDetails(new BigInteger("5555111151513301")));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Auto Payment can not be availed without an existing IBS account", throwable.getMessage());
		}
	}

	@Test
	public void showIBSServiceProvidersTest() {
		assertEquals(1, autoPaymentServiceImpl.showIBSServiceProviders().size());
	}

}